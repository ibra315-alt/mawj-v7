import { Settings } from './db'

/* ══════════════════════════════════════════════════
   APPEARANCE — Single source of truth
   Saves to Supabase. Loaded on every mount.
══════════════════════════════════════════════════ */

export const THEMES = [
  {
    id: 'dark',
    name: 'داكن',
    mode: 'dark',
    vars: {}  // all handled by CSS :root
  },
  {
    id: 'light',
    name: 'فاتح',
    mode: 'light',
    vars: {}  // all handled by CSS [data-theme="light"]
  },
]

export const DARK_THEMES  = THEMES.filter(t => t.mode === 'dark')
export const LIGHT_THEMES = THEMES.filter(t => t.mode === 'light')

export const DEFAULT_PREFS = {
  theme:'dark', mode:'dark', accent:'#00e4b8',
  font:"'Almarai', sans-serif",
  fontSize:'medium', radius:'rounded', density:'normal',
  animations:true, noise:true, spotlight:true,
}

export function hexRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  return r ? `${parseInt(r[1],16)},${parseInt(r[2],16)},${parseInt(r[3],16)}` : null
}

function setVar(k,v) { if(v) document.documentElement.style.setProperty(k,v) }

const ALL_THEME_VARS = [
  '--bg','--bg-alt','--bg-card','--bg-glass','--bg-glass-hover','--bg-hover',
  '--bg-border','--bg-surface','--sidebar-bg','--header-bg','--modal-bg',
  '--violet','--violet-light','--violet-bright','--violet-glow','--violet-soft','--violet-faint',
  '--teal','--teal-deep','--teal-glow','--teal-soft','--teal-faint',
  '--pink','--pink-glow','--pink-soft','--text','--text-sec','--text-muted',
  '--input-bg','--input-border','--input-focus',
  '--glass-border','--glass-border-strong','--glass-border-teal',
  '--shadow-card','--shadow-float','--shadow-violet','--shadow-teal',
]

export function applyThemeVars(themeId) {
  // Themes are fully defined in CSS — nothing to do here
}

export function applyAppearance(prefs) {
  const p = { ...DEFAULT_PREFS, ...prefs }

  // 1. Apply theme — dark or light (all colors handled by CSS)
  const mode = p.mode === 'light' ? 'light' : 'dark'
  document.documentElement.setAttribute('data-theme', mode)

  // 2. Animations toggle
  const as = document.getElementById('mawj-anim-style') || document.createElement('style')
  as.id = 'mawj-anim-style'
  as.textContent = p.animations ? '' : `
    .page,.stagger>*{animation:none!important}
    *{transition-duration:0.01ms!important}
  `
  if (!document.getElementById('mawj-anim-style')) document.head.appendChild(as)
}

export async function loadAndApplyAppearance(userId) {
  try {
    const userKey=userId?`appearance_${userId}`:'appearance'
    let prefs=await Settings.get(userKey)
    if(!prefs) prefs=await Settings.get('global_appearance')
    applyAppearance(prefs||DEFAULT_PREFS)
    return prefs||DEFAULT_PREFS
  } catch {
    applyAppearance(DEFAULT_PREFS)
    return DEFAULT_PREFS
  }
}

export async function saveAppearance(prefs,userId) {
  applyAppearance(prefs)
  const key=userId?`appearance_${userId}`:'appearance'
  await Settings.set(key,prefs)
}

export async function saveGlobalDefault(prefs) {
  applyAppearance(prefs)
  await Settings.set('global_appearance',prefs)
  await Settings.set('appearance',prefs)
}
